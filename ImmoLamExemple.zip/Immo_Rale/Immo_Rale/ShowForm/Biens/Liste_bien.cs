﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Immo_Rale.ShowForm.Biens
{
    public partial class Liste_bien : UserControl
    {
        private Management.Biens obj_biens;
        public Liste_bien()
        {
            InitializeComponent();
            lsBiens = Management.Biens.getList("");
            //lsVendeur = Management.Vendeur.getList("");
            dataGridView1.DataSource = lsBiens;
           // dataGridView1.Columns["ID"].Visible = false;
            //dataGridView1.Columns["FirstName"].Visible = false;
           // dataGridView1.Columns["LastName"].Visible = false;
        }
        private List<Management.Biens> lsBiens;
        //private List<Management.Vendeur> lsVendeur;
        public event EventHandler BiensSelected;

        private Management.Biens getSelectedBiens(Guid id)
        {
            obj_biens = lsBiens.First(biens => biens.Id == id);
            return obj_biens;
        }
        //private List<object> getSelectedBiens(Guid id)
        //{
        //    //MessageBox.Show(id.ToString());
        //    List<object> lst = new List<object>();
        //    Management.Biens obj = new Management.Biens();
        //    Management.Vendeur vd = new Management.Vendeur();
        //    obj = lsBiens.First(biens => biens.Id == id);
        //    vd = lsVendeur.First(vend => vend.Id == Guid.Parse(obj.Idvendeur));
        //    lst.Add(obj);
        //    lst.Add(vd);
        //    return lst;
        //}
        //private Management.Vendeur getSelectedVendeur(Guid id)
        //{
        //    id = Guid.Parse(obj_biens.Idvendeur);
        //    return lsVendeur.First(x => x.Id == id);
        //}

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //try
            //{
            //    Guid id = Guid.Parse(dataGridView1["ID", e.RowIndex].Value.ToString());
            //    if (id != null)
            //        //if (EmployeeSelected != null)
            //        EmployeeSelected(getSelectedEmployee(id), null);
            //    MessageBox.Show(id.ToString());
            //}
            //catch
            //{
            //}
            try
            {
                Guid id = Guid.Parse(dataGridView1["ID", e.RowIndex].Value.ToString()); //MessageBox.Show(id.ToString());
                //Guid id_vendeur = Guid.Parse(dataGridView1["idVendeur", e.RowIndex].Value.ToString());
                if (id != null)
                {
                    //if (EmployeeSelected != null)
                    BiensSelected(getSelectedBiens(id), null);
                }
                //MessageBox.Show(id.ToString());
            }
            catch (Exception ex)
            {
                
            }
            
        }
    }
}
