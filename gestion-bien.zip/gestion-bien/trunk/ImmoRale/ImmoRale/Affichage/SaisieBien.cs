﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImmoRale.Entites;

namespace ImmoRale.Affichage
{
    public partial class SaisieBien : UserControl
    {
        private BIEN test = new BIEN();

        public SaisieBien(ImmoRale.Entites.BIEN house = null)
        {
            InitializeComponent();
            if(house != null)
            {
                LoadDonnee(house);
            }
            
        }

        private void LoadDonnee(ImmoRale.Entites.BIEN maison)
        {
            textBox1.Text = maison.Adresse;
            textBox2.Text = maison.TypeHabitation;
            textBox3.Text = maison.NombreChambre.ToString();
            textBox4.Text = maison.NombreSalleBain.ToString();
            textBox5.Text = maison.DateMiseEnVente;
            textBox6.Text = maison.AvecGarage;

        }

        private void butSave_Click(object sender, EventArgs e)
        {
            test.Adresse = textBox1.Text;
            test.TypeHabitation = textBox2.Text;
            test.NombreChambre = int.Parse(textBox3.Text);
            test.NombreSalleBain = int.Parse(textBox4.Text);
            test.DateMiseEnVente = textBox5.Text;
            test.AvecGarage = textBox6.Text;
            Entites.BIEN.save(test);
        }


    }
}
