﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImmoRale.Affichage;
using ImmoRale.Entites;

namespace ImmoRale.Affichage
{
    public partial class AffichageDonnees : UserControl
    {
        private List<Tester> lsObj;
        private List<BIEN> listBien;
        public event EventHandler EmployeeSelected;
        public event EventHandler BienSelected;

        public AffichageDonnees()
        {
            InitializeComponent();

            lsObj = Tester.getList("");
            listBien = BIEN.getList("");
            dataGridView1.DataSource = lsObj;
            dataGridViewBien.DataSource = listBien;
            //dataGridView1.Columns["ID"].Visible = false;
            //dataGridView1.Columns["FirstName"].Visible = false;
            //dataGridView1.Columns["LastName"].Visible = false;
        }

        #region getSelected
        private Tester getSelectedEmployee(Guid id)
        {
            return lsObj.First(x => x.Id == id);
        }

        private BIEN getSelectedBien(Guid id)
        {
            return listBien.First(x => x.ID == id);
        }

        #endregion

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Guid id = Guid.Parse(dataGridView1["ID", e.RowIndex].Value.ToString());

            if (EmployeeSelected != null)
                EmployeeSelected(getSelectedEmployee(id), null);
        }

        private void dataGridViewBien_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Guid id = Guid.Parse(dataGridViewBien["ID", e.RowIndex].Value.ToString());

            /*
            String adr = dataGridViewBien["Adresse", e.RowIndex].Value.ToString();
            String typehb = dataGridViewBien["TypeHabitation", e.RowIndex].Value.ToString();
            Int16 nbchambre = Int16.Parse(dataGridViewBien["NombreChambre", e.RowIndex].Value.ToString());
            Int16 nbsallebain = Int16.Parse(dataGridViewBien["NombreSalleBain", e.RowIndex].Value.ToString());
            String date = dataGridViewBien["DateMiseEnVente", e.RowIndex].Value.ToString();
            String garage = dataGridViewBien["AvecGarage", e.RowIndex].Value.ToString();
            */

            if (BienSelected != null)
            {
                BienSelected(getSelectedBien(id), null);

                /*
                BienSelected(getSelectedAdresse(adr), null);
                BienSelected(getSelectedTypeHabitation(typehb), null);
                BienSelected(getSelectedNombreChambre(nbchambre), null);
                BienSelected(getSelectedNombreSalleBain(nbsallebain), null);
                BienSelected(getSelectedDateMiseEnVente(date), null);
                BienSelected(getSelectedAvecGarage(garage), null);
                */
            }
        }

        
        
    }
}
