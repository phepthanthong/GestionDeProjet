﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImmoRale.Entites;

namespace ImmoRale.Affichage
{
    public partial class Saisie : UserControl
    {
        private Tester test = new Tester();
        public Saisie()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            test.Somot = textBox1.Text;
            test.Sohai = textBox2.Text;
            Entites.Tester.save(test);

        }
    }
}
