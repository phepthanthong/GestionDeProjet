﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ImmoRale.Affichage;

namespace ImmoRale
{
    public partial class GestionBien : Form
    {
        private UserControl usercontrol;
        private TabControl tab;

        public GestionBien()
        {
            InitializeComponent();
           
            ChangerPage(tabPage1, new SaisieBien());        
        }

        private void ChangerPage(TabPage table, UserControl uc)
        {
            uc.Size = table.Size;
            table.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            table.Controls.Add(uc);
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab == tabPage1)
            {
                ChangerPage(tabPage1, new SaisieBien());

            }
            else if (tabControl1.SelectedTab == tabPage2)
            {
                AffichageDonnees a = new AffichageDonnees();
                ChangerPage(tabPage2, a);
                a.BienSelected += (s1, e1) =>
                    {
                        tabControl1.SelectedTab = tabPage1;
                        ChangerPage(tabPage1, new SaisieBien((ImmoRale.Entites.BIEN)s1));
                    };

               

            }
        }
    }
}
